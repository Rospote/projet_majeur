package com.cpe.connexion.admin.controller;

/*
import java.util.ArrayList;
import java.util.List;
*/

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cpe.connexion.admin.model.Admin;

@Service // L'application Spring Boot sait que cette classe correspond à un service
public class AdminService {

	@Autowired // nous met en lien avec le repertoire de carte connectee a la db
	private AdminRepository adminRepository;

	/**
	 * 
	 * @param id
	 * @return l'admin avec l'id correspondant
	 */
	public Admin getAdmin(String id) {
		return adminRepository.findOne(Integer.valueOf(id));
	}

	/**
	 * Ajoute un admin 
	 * @param admin
	 */
	public void addAdmin(Admin admin) {
		adminRepository.save(admin);
	}
	/**
	 * Modifie un admin 
	 * @param admin
	 */
	public void updateAdmin(Admin admin) {
		adminRepository.save(admin);

	}
	/**
	 * Supprime un admin 
	 * @param admin
	 */
	public void deleteAdmin(String id) {
		adminRepository.delete(Integer.valueOf(id));
	}

	public boolean isLoginIn (Admin admin) {
		return !adminRepository.findByLoginAndPassword(admin.getLogin(), admin.getPassword()).isEmpty();
	}
}
