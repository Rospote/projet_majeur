package com.cpe.connexion.admin.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cpe.connexion.admin.model.Admin;

/*
 * Controller Restful -> gère les requêtes http du type methodes get, post, put et delete et renvoie une page JSON
 */
@RestController
public class AdminRestController {
	// déclare le service qu'on utilise. Fait le lien entre le controller et une instance de AdminService
	@Autowired
	private AdminService adminService;
/**
 * mapping methode post pour ajouter un admin
 * @param admin
 */
	@RequestMapping(method=RequestMethod.POST,value="/admins")
	public void addAdmin(@RequestBody Admin admin) {
		adminService.addAdmin(admin);
	}
	
	//@PathVariable permet d'indiquer une variable dans l'URL
	/**
	 * @param id de l'admin
	 * mapping methode put pour modifier un admin
	 */
	@RequestMapping(method=RequestMethod.PUT,value="/admins/{id}")
	public void updateAdmin(@RequestBody Admin admin,@PathVariable String id) {
		admin.setId(Integer.valueOf(id));
		adminService.updateAdmin(admin);
	}
	/**
	 * 
	 * @param id de l'admin
	 * mapping methode delete pour supprimer un admin
	 */
	@RequestMapping(method=RequestMethod.DELETE,value="/admins/{id}")
	public void deleteAdmin(@PathVariable String id) {
		adminService.deleteAdmin(id);
	}
/**
 * mapping methode post
 * @param admin
 * @return boolean si l'admin est connecté ou non
 */

	@RequestMapping(method=RequestMethod.POST,value="/login")
	
	public boolean isLoginIn(@RequestBody Admin admin) {
		return adminService.isLoginIn(admin);
	}
	

}
