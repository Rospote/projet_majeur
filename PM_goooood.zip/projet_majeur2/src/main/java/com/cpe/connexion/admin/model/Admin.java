package com.cpe.connexion.admin.model;
//package com.cpe.springboot.user.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

//import org.hibernate.annotations.Table;

@Entity //This tells Hibernate to make a table out of this class

@Table (name="admins_PM")

public class Admin {
	
	@Id //clé primaire  pour la base de donnée
	@GeneratedValue(strategy=GenerationType.AUTO)
    private Integer id;
	private String login;
	private String password;

	public Admin() {
		this.login ="";
		this.password="";
	}
	
	public Admin(String login, String password) {
		this.login = login;
		this.password=password;
	}

	//Getters & setters
	
	
	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}
	
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

}