package com.cpe.connexion.connexion_robot_utilisateur;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
//import com.cpe.springboot.robot_web_services.model.Env;

@RestController
public class ConnexionRestController{
	
	@Autowired
	private ConnexionService simulateurService;
	
//	@RequestMapping("/cmd/{cmd_key}")
//	private void applyMvt(@PathVariable String cmd_key){
//		simulateurService.applyMvt(cmd_key);
//	}

	@RequestMapping(value = "/state")
	public void state() {
		simulateurService.switchState();
	}
	
	@RequestMapping(value = "/use/{id}")
	public void updateUser(@PathVariable String id){
		simulateurService.updateUser(id);
	}
	
	//get l'user courant
	@RequestMapping(value = "/use/get")
	public String updateUser(){
		return simulateurService.getUtilisateurCourant();
	}
	
	//get l'état courant
	@RequestMapping(value = "/state/get")
	public String getState(){
		return simulateurService.getState();

	}
	
	//get l'état courant
		@RequestMapping(value = "/lock/get")
		public boolean isLocked(){
			return simulateurService.isLocked();

		}
		
	//change l'état courant
		@RequestMapping(value = "/lock")
		public void switchLocked(){
			simulateurService.switchLocked();

		}
	
	//change power du robot 
	@RequestMapping(value = "/power")
	public void switchPowerOn(){
		simulateurService.switchPowerOn();
		System.out.println(this.isPowerOn());

	}
	
	//return power du robot
	@RequestMapping(value = "/power/get")
	public boolean isPowerOn(){
			return simulateurService.isPowerOn();	
	}
	
	/*@RequestMapping("/env")
	private Env getEnv(){
		return robotCrtService.getEnv();
	}
	
	@RequestMapping("/envRobot")
	private Env getEnvRobot(){
		return robotCrtService.getEnvRobot();
	}*/
}