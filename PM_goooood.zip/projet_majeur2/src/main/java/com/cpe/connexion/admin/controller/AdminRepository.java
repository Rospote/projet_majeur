package com.cpe.connexion.admin.controller;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.cpe.connexion.admin.model.Admin;

public interface AdminRepository extends CrudRepository<Admin, Integer> {
	
	public List<Admin> findByLoginAndPassword(String login, String password);	

}
