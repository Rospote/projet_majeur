package com.cpe.connexion.connexion_robot_utilisateur;

import org.springframework.stereotype.Service;

import com.cpe.simulation.model.RobotCrt;
import com.cpe.simulation.model.Simulation;




@Service // L'application Spring Boot sait que cette classe correspond à un service
public class ConnexionService {
	private Simulation simulation;
	private RobotCrt robotCrt; 
	private String utilisateurCourant;
	private boolean isLocked;	
	private boolean powerOn;
	

	public ConnexionService() {
		this.simulation = new Simulation();
		this.robotCrt = simulation.getControleur();
		this.utilisateurCourant = "None";
		this.isLocked = false;	
		this.powerOn = false;
	}

	public String getUtilisateurCourant() {
		return utilisateurCourant;
	}

	public void setUtilisateurCourant(String utilisateurCourant) {
		this.utilisateurCourant = utilisateurCourant;
	}

//	public void applyMvt(String cmd_key) {
//		switch (cmd_key) {
//			case "UP":
//				simulation.RobotUp();
//				System.out.println("Robot monte");
//				break;
//			case "DOWN":
//				simulation.RobotDown();
//				System.out.println("Robot descend");
//				break;
//			case "RIGHT":
//				simulation.RobotRight();
//				System.out.println("Robot droite");
//				break;
//			case "LEFT":
//				simulation.RobotLeft();
//				System.out.println("Robot gauche");
//				break;
//		}
//	}
	
	public void switchState() {
		if (simulation.getState()=="Free") {
			simulation.setState("Busy");
		}
		else {
			simulation.setState("Free");
		}
	}
	
	public String getState() {
		return simulation.getState();
	}

	public void updateUser(String id) {
		this.setUtilisateurCourant(id);
	}

	public boolean isLocked() {
		return isLocked;
	}

	public void switchLocked() {
		this.isLocked = !(this.isLocked);
	}

	public boolean isPowerOn() {
		return powerOn;
	}

	public void switchPowerOn() {
		this.powerOn = !(this.powerOn);
	}
	
}