package com.cpe.simulation.model;

import java.awt.Dimension;
import java.awt.Point;
import java.util.ArrayList;
import java.util.Collection;

// liste de robots, pour avoir plusieurs robots sur le terrain
public class Simulation_list {
	/*
	private ArrayList<RobotCrt> list= new ArrayList<RobotCrt>();
	RobotCrt controleur;
	Env environement;
	
	public Simulation_list() {
		super();
		this.environement = new Env(new Dimension(10,10),20);
	}

	
	public void SwitchControleur(int ID) {
		for (RobotCrt crt: list) {
			if(crt.ID == ID) {
				controleur = crt;
			}
		}
	}
	
	public void newRobot(int ID) {
		list.add(new RobotCrt(new Robot(new Point(0,0), Capteur.Orientation.EST),ID));
		SwitchControleur(ID);
	}
	public ArrayList<RobotCrt> afficheList(){
		return this.list;
	}
	
	public void RobotUp() {
		controleur.robotUp(environement);
	}
	
	public void RobotDown() {
		controleur.robotDown(environement);
	}
	
	public void RobotLeft() {
		controleur.robotLeft(environement);
	}
	
	public void RobotRight() {
		controleur.robotRight(environement);
	}

	public Env GetEnvironementRobot() {
		return controleur.getEnvironementRobot();
	}
	
	public Env GetEnvironement() {
		return this.environement;
	}
	
//	public static void main(String[] args) {
//		Simulation_list sim= new Simulation_list();
//		sim.newRobot(0);
//		System.out.println("env general: "+sim.GetEnvironement().toString()+sim.afficheList());
//		
//		
//		
//		System.out.println("env robot debut : "+sim.GetEnvironementRobot());
//		sim.RobotDown();
//		System.out.println("env robot down : "+sim.GetEnvironementRobot());
//		sim.RobotDown();
//		sim.RobotDown();
//		sim.RobotDown();
//		sim.RobotRight();
//		System.out.println("env robot down : "+sim.GetEnvironementRobot());
//	}
*/
}
