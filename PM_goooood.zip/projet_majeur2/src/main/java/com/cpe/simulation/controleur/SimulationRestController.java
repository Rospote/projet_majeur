package com.cpe.simulation.controleur;


import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController //On indique qu'il s'agit d'un controlleur
public class SimulationRestController {
	
	@Autowired
	private SimulationService simulationService;
	


	@RequestMapping("/map")
	private ArrayList<String> getAllCourses() {
		return simulationService.getDataEnvironementRobot();
	}

	
	@RequestMapping("/cmd/{cmd_key}")
	private void applyMvt(@PathVariable String cmd_key){
		simulationService.applyMvt(cmd_key);
	}
	
}
