package com.cpe.simulation.controleur;



import java.util.ArrayList;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.cpe.simulation.model.Env;
import com.cpe.simulation.model.Measures;
import com.cpe.simulation.model.RobotCrt;
import com.cpe.simulation.model.Simulation;



@Service // L'application Spring Boot sait que cette classe correspond à un service
public class SimulationService {
	private Simulation simulation;
	private RobotCrt robotCrt; 
	boolean auto;
	//HashMap<Integer, String> simulationList; 
	
	public SimulationService() {
		auto = false;
		simulation = new Simulation();
		//simulation.newRobot(0);

		
	}
	
	@Scheduled(fixedRate = 1000)
	public void scheduleTaskWithFixedRate() {
		  System.out.println("RUN");
	      if(auto) {
	    	 simulation.autoMove();
	      }
	}


	public void applyMvt(String cmd_key) {
		switch (cmd_key) {
			case "UP":
				simulation.RobotUp();
				System.out.println("Robot monte");
				break;
			case "DOWN":
				simulation.RobotDown();
				System.out.println("Robot descend");
				break;
			case "RIGHT":
				simulation.RobotRight();
				System.out.println("Robot droite");
				break;
			case "LEFT":
				simulation.RobotLeft();
				System.out.println("Robot gauche");
				break;
			case "AUTO":
				switchAuto();
				System.out.println("Switch auto");
				break;
			case "RESET":
				reset();
				System.out.println("Reset");
				break;
		}
	}

	public ArrayList<String> getDataEnvironementRobot() {
		return simulation.getEnvironementRobot().toJson(simulation.getControleur().getRobot().getPosition());
	}
	
	public ArrayList<String> getDataMeasures() {
		Measures m = simulation.getControleur().getMeasures();
		ArrayList<String> list = new ArrayList<String>();
		list.add(m.getNbCommandesExec()+"");
		list.add(m.getDistanceParcourue()+"");
		list.add(m.getNbObstaclesVisibles()+"");
		list.add(m.getNbObstaclesRencontre()+"");
		
		return list;
	}
	public void switchAuto(){
		this.auto = !this.auto;
	}

	public void reset() {
		this.simulation = new Simulation();
	}
//	public void switchState(int id){
//		if(simulationList.containsKey(id)) {
//			if(simulationList.get(id)== "free") {
//				simulationList.put(id, "busy");
//				System.out.println(id + "busy");
//			}
//			else {
//				simulationList.put(id, "free");
//				System.out.println(id + "free");
//			}
//			
//		}
//	}
	
}