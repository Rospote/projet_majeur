package com.cpe.simulation.model;

import java.awt.Dimension;
import java.awt.Point;
import java.util.ArrayList;
import java.util.Formatter;
import java.util.Locale;
import java.util.Random;

public class Env {
	
	private int pourcentageObtacle;
	private String [][] matricEnv ;
	private Dimension dim;
	
	public Env(Dimension dim, int pourcentageObtacle){
		this.dim=dim;
		this.pourcentageObtacle=pourcentageObtacle;	
		this.matricEnv=generationEnv(dim, pourcentageObtacle);
	}
	
	/**
	 * 
	 * @param dim
	 * @param pourcentageObtacle
	 * @return une matrice contenant des obstacles aleatoirement, en fonction du poucentage voulu
	 */
	public String[][] generationEnv(Dimension dim, int pourcentageObtacle){
		matricEnv = new String[dim.height][dim.width];
		matricEnv= remplissageMatrice("FREE");
		int nbCases= dim.height*dim.width;
		int nbObstacles = (nbCases*pourcentageObtacle)/100;
		for (int i =0;i<nbObstacles;i++){
			int randY = new Random().nextInt(dim.height);
			int randX = new Random().nextInt(dim.width);
			//si la case est deja occupée par un osbtacle
			while(getContenuCase(randX,randY)!="FREE"){
				randY = new Random().nextInt(dim.height);
				randX = new Random().nextInt(dim.width);

			}
			matricEnv[randY][randX]= "OBSTACLE";

		}	
		return matricEnv;
		
	}
	/**
	 * 
	 * @param etat
	 * @return remplit la matrice
	 */
	public String[][] remplissageMatrice(String etat){
		for(int i=0;i<this.dim.height;i++){
			for(int j=0;j<this.dim.width;j++){
				matricEnv[i][j]=etat;
			}
		}
		return matricEnv;
		
	}
	public String[][] getMatricEnv(){
		return this.matricEnv;
	}
	public String getContenuCase(int x, int y){
		return this.matricEnv[y][x];
		
	}
	
	public void setContenuCase(int x, int y, String value){
		this.matricEnv[y][x] = value;
	}
	
	public Dimension getDim(){
		return dim;
	}
	/**
	 * 
	 * @param matrix
	 * @param sizeX
	 * @param sizeY
	 * @return permet d'afficher une matrice de string
	 */
	public static String printMatrix(String[][] matrix,int sizeX,int sizeY) {
		 StringBuilder sb = new StringBuilder();
		 Formatter formatter = new Formatter(sb, Locale.FRENCH);
		 String formatS = "%1$5s";
		 String[] valueTab = new String[sizeX+1];
		 valueTab[0]="";
		 for (int index = 0; index < sizeX; index++) {
		 formatS = formatS + " %" + (index + 2) + "$5s";
		 valueTab[index+1] = String.valueOf(index);
		 }
		 formatter.format(formatS + "\n", valueTab);
		 formatter.format("%1$5s | %2$47s\n", "",
		 "_______________________________________________");
		 for (int i = 0; i < sizeY; i++) {
			 String formatS2 = "%1$5s | ";
			 String[] valueTab2 = new String[sizeY+1];
			 valueTab2[0]=String.valueOf(i);
			 for (int j = 0; j < sizeX; j++) {
				 formatS2 = formatS2 + " %" + (j + 2) + "$5s";
				 valueTab2[j+1] = matrix[i][j];
			 }
		 formatter.format(formatS2 + "\n", valueTab2);
		 }
		 return formatter.toString();
	}
	

/**
 * conversion de la matrice de string en JSON
 * @param posrobot
 * @return JSON
 */
	public ArrayList<String> toJson(Point posrobot){
		ArrayList<String> list = new ArrayList<String>();

		list.add(Double.toString(dim.getHeight()));
		list.add(Double.toString(dim.getWidth()));
		int i = 0;
		for(int y = 0;y < dim.getHeight();y++) {
			for(int x = 0;x < dim.getWidth();x++) {
				if(y == posrobot.y && x == posrobot.x) {
					list.add("ROBOT");
				}else {
					list.add(this.matricEnv[y][x]);
				}
				i++;
			}
		}
		return traductionJson(list);
		
	}
	
	public ArrayList<String> traductionJson(ArrayList<String> list){
		ArrayList<String> newlist = new ArrayList<String>();
		for (String str: list) {
			switch(str) {
			case "UNKNOWN":
				newlist.add("1");
				break;
			case "FREE":
				newlist.add("2");
				break;
			case "OBSTACLE":
				newlist.add("3");
				break;
			case "ROBOT":
				newlist.add("4");
				break;
			case "TRACE":
				newlist.add("5");
				break;
			case "OBSTACLE_HEURTE":
				newlist.add("6");
				break;
			default:
				newlist.add(str);
				break;
			}
		}
		return newlist;
		
	}
	public int nbObstacles(){
        int count = 0;
        for(int y = 0;y < dim.getHeight();y++) {
            for(int x = 0;x < dim.getWidth();x++) {
                    if(this.matricEnv[y][x] == "OBSTACLE") {
                        count++;
                    }
                    if(this.matricEnv[y][x] == "OBSTACLE_HEURTE") {
                        count++;
                    }
            }
        }
        return count;
    }
	
	public String toString(){
		String env=Env.printMatrix(this.getMatricEnv(),this.dim.width, this.dim.height);
		return env;
		
	}
	public static void main(String[] args) {
		Dimension dim = new Dimension(10,10);
		Env env = new Env(dim,20);
		System.out.println(printMatrix(env.getMatricEnv(),dim.width,dim.height));
	}
}
