package com.cpe.simulation.model;

public class Measures {

	int nbCommandesExec;
	
	int nbObstaclesRencontre;
	
	int nbObstaclesVisibles;
	
	int distanceParcourue;

	public Measures() {
		super();
		this.nbCommandesExec = 0;
		this.nbObstaclesRencontre = 0;
		this.nbObstaclesVisibles = 0;
		this.distanceParcourue = 0;
	}

	public int getNbCommandesExec() {
		return nbCommandesExec;
	}

	public void setNbCommandesExec(int nbCommandesExec) {
		this.nbCommandesExec = nbCommandesExec;
	}

	public int getNbObstaclesRencontre() {
		return nbObstaclesRencontre;
	}

	public void setNbObstaclesRencontre(int nbObstaclesRencontre) {
		this.nbObstaclesRencontre = nbObstaclesRencontre;
	}

	public int getNbObstaclesVisibles() {
		return nbObstaclesVisibles;
	}

	public void setNbObstaclesVisibles(int nbObstaclesVisibles) {
		this.nbObstaclesVisibles = nbObstaclesVisibles;
	}

	public int getDistanceParcourue() {
		return distanceParcourue;
	}

	public void setDistanceParcourue(int distanceParcourue) {
		this.distanceParcourue = distanceParcourue;
	}
	
	
}
