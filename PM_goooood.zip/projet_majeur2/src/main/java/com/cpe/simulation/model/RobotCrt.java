package com.cpe.simulation.model;

import java.awt.Point;
import java.util.Random;


public class RobotCrt {
	
	private Robot robot;
	private Measures measures;

	public RobotCrt(Robot robot) {
		super();
		this.robot = robot;
		this.measures= robot.measures;

	}
	
	public Measures getMeasures() {
		return measures;
	}

	public void setMeasures(Measures measures) {
		this.measures = measures;
	}

	public Env getEnvironement(Env environement) {
		return environement;
	}

	public Robot getRobot() {
		return robot;
	}

	public void setRobot(Robot robot) {
		this.robot = robot;
	}
	
	public boolean robotUp(Env environement){
		robot.setOrientation(Capteur.Orientation.NORD);
		Point pos = robot.getPosition();
		//verification des limites du robot
		if(pos.y>0){
			//si la case d'arrivée est disponible
			if(environement.getContenuCase(pos.x, pos.y-1) != "OBSTACLE" && environement.getContenuCase(pos.x, pos.y-1) != "OBSTACLE_HEURTE"){
					int y = pos.y - 1;
					//recupere l'environnement du robot à l'aide du capteur 
					robot.scan(environement);
					// maj de la position du robot
					robot.setPosition(new Point(pos.x,y),environement);
					robot.scan(environement);
					measures.distanceParcourue++;
		
					return true;
				}
				else 	{
					//si l'obstacle à deja ete rencontré
					int y = pos.y - 1;
					environement.setContenuCase(pos.x, y, "OBSTACLE_HEURTE");
					System.out.println("OBSTACLE RENCONTRE");
					measures.nbObstaclesRencontre++;
					robot.scan(environement);
		
				}
		}else{
			System.out.println("HORS TERRAIN");
		}

		
		
		return false;
	}
	
	public boolean robotDown(Env environement){
		robot.setOrientation(Capteur.Orientation.SUD);
		Point pos = robot.getPosition();
		
		if(pos.y < (environement.getDim().height)-1){
		
			if(environement.getContenuCase(pos.x, pos.y+1) != "OBSTACLE" && environement.getContenuCase(pos.x, pos.y+1) != "OBSTACLE_HEURTE"){
				int y = pos.y + 1;
				robot.scan(environement);//TODO FAIT BUGGER
				robot.setPosition(new Point(pos.x,y),environement);
				robot.scan(environement);
				measures.distanceParcourue++;
				return true;
			}	
			else 	{
				int y = pos.y + 1;
				environement.setContenuCase(pos.x, y, "OBSTACLE_HEURTE");
				System.out.println("OBSTACLE RENCONTRE");
				measures.nbObstaclesRencontre++;
				robot.scan(environement);
	
			}
		}else{
			System.out.println("HORS TERRAIN");
		}
		
		return false;
	}
	
	public boolean robotLeft(Env environement){
		robot.setOrientation(Capteur.Orientation.OUEST);
		Point pos = robot.getPosition();
		
		if(pos.x>0){
			if((environement.getContenuCase(pos.x - 1, pos.y) != "OBSTACLE") && (environement.getContenuCase(pos.x - 1, pos.y) != "OBSTACLE_HEURTE") ){
				int x = pos.x - 1;
				robot.setPosition(new Point(x,pos.y),environement);
				robot.scan(environement);
				measures.distanceParcourue++;
	
				return true;
			}
			else {
				int x = pos.x - 1;
				environement.setContenuCase(x, pos.y, "OBSTACLE_HEURTE");
				robot.scan(environement);
				System.out.println("OBSTACLE RENCONTRE");
				measures.nbObstaclesRencontre++;
				robot.scan(environement);
	
			}
		}
		else{
			System.out.println("HORS TERRAIN");
		}
		return false;
	}
	
	public boolean robotRight(Env environement){
		robot.setOrientation(Capteur.Orientation.EST);
		Point pos = robot.getPosition();
		
		if( pos.x <environement.getDim().width-1){
			if(environement.getContenuCase(pos.x + 1, pos.y) != "OBSTACLE" && environement.getContenuCase(pos.x + 1, pos.y) != "OBSTACLE_HEURTE"){
				int x = pos.x + 1;
				robot.scan(environement);
				robot.setPosition(new Point(x,pos.y),environement);
				robot.scan(environement);
				measures.distanceParcourue++;
	
				return true;
			}
			else 	{
				int x = pos.x + 1;
				environement.setContenuCase(x, pos.y, "OBSTACLE_HEURTE");
				System.out.println("OBSTACLE RENCONTRE");
				measures.nbObstaclesRencontre++;
				robot.scan(environement);
	
			}
		}else{
			System.out.println("HORS TERRAIN");
		}
		
		return false;
	}
	
	public Env getEnvironementRobot()
	{
		Env environement = robot.getEnvironement();
		
		return environement;
	}
	

//	public void updateEnvRobot(){
//		Env environement = getEnvironementRobot();
//		
//	}
	

	/**
	 * changement d'orientation du robot
	 */
	public void changeOrientation() {
		int rand = new Random().nextInt(2);
		
		switch(robot.getOrientation()) {
		case NORD:
			//changement d'orientation aleatoirement soit à droite soit à gauche
			if(rand == 1) {
				robot.setOrientation(Capteur.Orientation.EST);	
			}else {
				robot.setOrientation(Capteur.Orientation.OUEST);	
			}

			break;
		case EST:
			if(rand == 1) {
				robot.setOrientation(Capteur.Orientation.SUD);	
			}else {
				robot.setOrientation(Capteur.Orientation.NORD);	
			}
			break;
		case SUD:
			if(rand == 1) {
				robot.setOrientation(Capteur.Orientation.EST);	
			}else {
				robot.setOrientation(Capteur.Orientation.OUEST);	
			}
			break;
		case OUEST:
		default:
			if(rand == 1) {
				robot.setOrientation(Capteur.Orientation.NORD);	
			}else {
				robot.setOrientation(Capteur.Orientation.SUD);	
			}	
			break;
		}
		
	}
	
}
