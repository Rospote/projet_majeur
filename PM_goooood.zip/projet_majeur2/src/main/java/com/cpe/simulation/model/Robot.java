package com.cpe.simulation.model;

import java.awt.Dimension;
import java.awt.Point;
import java.util.ArrayList;



public class Robot{
	
	
	public Point position;
	
	Capteur.Orientation orientation;
	
	Capteur capteur;
	Measures measures = new Measures();
	


	public Env environement; //Environement découvert par le robot.

	
	public Robot(Point position, Capteur.Orientation orientation) {
		super();
		this.position = position;
		this.orientation = orientation;
		this.environement = new Env(new Dimension(10,10),0);
		this.environement.remplissageMatrice("UNKNOWN");
		this.capteur = new Capteur(3);

	}
	
		
	public Capteur.Orientation getOrientation() {
		return orientation;
	}

	public void setOrientation(Capteur.Orientation orientation) {
		this.orientation = orientation;
	}


	public void setEnvironement(Env environement) {
		this.environement = environement;
	}



	public Point getPosition() {
		return position;
	}

	public void setPosition(Point position,Env trueEnvironement) {
		//maj de l'environnement du robot
		this.environement.setContenuCase(this.position.x, this.position.y, "TRACE");
		//ajout de la trajectoire du robot sur l'environnement general
		trueEnvironement.setContenuCase(this.position.x, this.position.y, "TRACE");
		//maj de la position 
		this.position = position;
		//maj de la position du robot sur la map
		this.environement.setContenuCase(this.position.x, this.position.y, "ROBOT");
		measures.nbCommandesExec++;
	}

	public Capteur getCapteur() {
		return capteur;
	}

	public void setCapteur(Capteur capteur) {
		this.capteur = capteur;
	}
	/**
	 * 
	 * @param trueEnvironement
	 * fonction permettant de recuperer les données de l'environnement general à l'aide du capteur pour mettre à jour l'environnement du robot
	 */
	public void scan(Env trueEnvironement) {
		//recupere le patern du capyteur
		 ArrayList<Point> patern = capteur.capte(position, orientation);
		 
		 for (Point p: patern) {
			// si le capteur ne depasse pas du terrain
			 if(p.x>=0 && p.y>=0 && p.x<environement.getDim().width && p.y < environement.getDim().height){
				 this.environement.setContenuCase(p.x, p.y, trueEnvironement.getContenuCase(p.x, p.y)); 
				
			 }
			 measures.nbObstaclesVisibles= this.environement.nbObstacles();
			 	
			}
		 
	}



	public Env getEnvironement() {
		return environement;
	}

	
	
}
