package com.cpe.simulation.model;

import java.awt.Dimension;
import java.awt.Point;
import java.util.Random;

// simulation avec un seul robot sur le terrain 

public class Simulation{
		
	private String state;
	private RobotCrt controleur;
	private Env environement;

	
	
	public Simulation() {
		super();
		this.setState("Free");
		this.controleur = new RobotCrt(new Robot(new Point(5,7), Capteur.Orientation.EST));
		this.environement = new Env(new Dimension(10,10),20);

	}
	
	public boolean RobotUp() {
		return controleur.robotUp(environement);
	}
	
	public boolean RobotDown() {
		return controleur.robotDown(environement);
	}
	
	public boolean RobotLeft() {
		return controleur.robotLeft(environement);
	}
	
	public boolean RobotRight() {
		return controleur.robotRight(environement);
	}

	public Env getEnvironementRobot() {
		return controleur.getEnvironementRobot();
	}
	
	public Env GetEnvironement() {
		return this.environement;
	}

	public RobotCrt getControleur() {
		return controleur;
	}

	public void setControleur(RobotCrt controleur) {
		this.controleur = controleur;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}
	
	/**
	 * fonction permettant de faire avancer le robot automatiquement 
	 */
	public void autoMove() {
		
		switch(controleur.getRobot().getOrientation()) {
		case NORD:
			// si le robot ne peut pas avancer car il rencontre un obstacle alors il change d'orientation
			if(!RobotUp()) {
				controleur.changeOrientation();
			}
			break;
		case EST:
			if(!RobotRight()) {
				controleur.changeOrientation();
			}
			break;
		case SUD:
			if(!RobotDown()) {
				controleur.changeOrientation();
			}
			break;
		case OUEST:
			if(!RobotLeft()) {
				controleur.changeOrientation();
			}
		default:				
			break;
		}
		// change d'orientation aleatoirements
		int rand = new Random().nextInt(100);
		if(rand < 20) {
			controleur.changeOrientation();
		}
	}
	
	
//	public static void main(String[] args) {
//		Simulation sim= new Simulation();
//		System.out.println("env general: "+sim.GetEnvironement().toString());
//
//		//System.out.println("env robot debut : "+sim.GetEnvironementRobot());
//		sim.RobotUp();
//		System.out.println("env robot UP : "+sim.getEnvironementRobot());
//
//		sim.RobotUp();
//		System.out.println("env robot UP : "+sim.getEnvironementRobot());
//
//		sim.RobotUp();
//		System.out.println("env robot UP : "+sim.getEnvironementRobot());
//
//		sim.RobotUp();
//		System.out.println("env robot UP : "+sim.getEnvironementRobot());
//	}
	

	


	
  
}
