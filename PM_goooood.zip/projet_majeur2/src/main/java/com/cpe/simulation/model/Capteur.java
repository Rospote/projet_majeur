package com.cpe.simulation.model;

import java.awt.Point;
import java.util.ArrayList;


public class Capteur {
	
	private int taille;
	
	public enum Orientation {
		  NORD,
		  SUD,
		  EST,
		  OUEST;	
		}
	
	
	
	public Capteur(int taille) {
		super();
		this.taille = taille;
	}
	
	public int getTaille() {
		return taille;
	}

	public void setTaille(int taille) {
		this.taille = taille;
	}
/**
 * 
 * @param pos
 * @param orientation
 * @return liste de point que le capteur voit, en cône 
 */
	public ArrayList<Point> capte(Point pos,Orientation orientation){
		
		ArrayList<Point> list = new ArrayList<Point>();
		int largeurCone= this.taille;
		int hauteurCone=this.taille;
		
		switch(orientation){
		
		case NORD:
			for(int i=0;i<hauteurCone;i++){
				for(int j=1;j<=i;j++){
				list.add(new Point((pos.x-j),pos.y-1-i));
				list.add(new Point((pos.x+j),pos.y-1-i));
				}
				list.add(new Point(pos.x,pos.y-1-i));
				
			}
			

			
			break;
			
		case SUD:
			for(int i=0;i<hauteurCone;i++){
				for(int j=1;j<=i;j++){
					list.add(new Point((pos.x-j),pos.y+1+i));
					list.add(new Point((pos.x+j),pos.y+1+i));
				}
				list.add(new Point(pos.x,pos.y+1+i));
				
			}

			
			break;
			
		case OUEST:
			
			for(int i=0;i<largeurCone;i++){
				for(int j=0;j<=i;j++){
					list.add(new Point((pos.x-1-i),pos.y+j));
					list.add(new Point((pos.x-1-i),pos.y-j));
				}
				list.add(new Point(pos.x-1-i,pos.y));
				
			}
			break;
			
		case EST:
			for(int i=0;i<largeurCone;i++){
				for(int j=0;j<=i;j++){
					list.add(new Point((pos.x+1+i),pos.y+j));
					list.add(new Point((pos.x+1+i),pos.y-j));
				}
				list.add(new Point(pos.x+1+i,pos.y));	
			}
			

			
			break;
			
		}
		return list;
		
	}
	public static void main(String[] args) {
		
	}

	}