

class Button {
	
	constructor(type){
		this.type = type;
		this.getType = this.getType.bind(this);
	}
	
	getType(){
		return(this.type);
	};
	
}

//Export the current objet, needed to make the import in the file cmd.js
export {Button};