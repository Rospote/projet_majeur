//import {Request} from './ajaxRequest.js';

class CbValue {
   

    constructor() {
       
        var power;
        this.defineInteractions= this.defineInteractions.bind(this);
        this.defineInteractions();
       
  }

    defineInteractions(){
       
        //Verification pour savoir si l'utilisateur a bien accès à la
//page suite à une connexion
        if (sessionStorage.getItem('id')!=1){
            window.location="/admin.html";
            document.body.innerHTML = "Accès refusé, veuillez vous connecter";
        }
        else {
           
        //Switch sur l'état du robot
        $.ajax ({
            success: function (power) {
                    this.power=power;
                    //alert(this.power);
                    $( "#myonoffswitch" ).prop( "checked", this.power );
                  }.bind(this)
                ,
                failure: function(errMsg) {
                    alert(errMsg);
                },
                type: "GET",
                url: "/power/get",
                // The key needs to match your method's input parameter(case-sensitive).
                contentType: "application/json; charset=utf-8"   
      });   
       
        $("input[type='checkbox']").on('change', function() {
            let req = new XMLHttpRequest();
            req.open("GET", "/power");
            req.onload = function() {
                if (req.status === 200) {
                    resolve(req.response);
                } else {
                   
                    reject(new Error(req.statusText));
                }
            };
            req.onerror = function() {
                reject(new Error("Network error"));
            };
            req.send();

        }.bind(this));
       
        //déconnexion
       
        $("#buttonId").click(
                function(){
                  this.deconnexion();
                  }.bind(this)
            );
        }
    }

    deconnexion(){
       
        sessionStorage.removeItem('id');
        window.location="/admin.html";
    }

}

$(function() {
   
    let cbvalue = new CbValue();

});