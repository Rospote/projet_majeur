//import {MapMng} from './MapMng.js';
//
//$(function() {
//  var c = $("canvas")[0].getContext("2d");
//  let mapMng=new MapMng(c,[]);
//  
//  $.ajax ({
//  	success: function (data) {
//  		//alert(data[5]);
//  		
//  		if($("input[id='myonoffswitch']").is(':checked')){
//  			var trace = '"4":'
//	   				+'{'
//	   					+'"image":"..\/img\/mapPack\/PNG\/mapTile_054.png",'
//	   					+'"imageheight":64,'
//	   					+'"imagewidth":64'
//	   				+'},';
//  		}else{
//  			var trace = '"4":'
//   				+'{'
//					+'"image":"..\/img\/mapPack\/PNG\/mapTile_077.png",'
//					+'"imageheight":64,'
//					+'"imagewidth":64'
//				+'},';
//
//  		}
// 		if($("input[id='myonoffswitch2']").is(':checked')){
//  			var robot = '"3":'
//	   				+'{'
//	   					+'"image":"..\/img\/mapPack\/PNG\/mapTile_136.png",'
//	   					+'"imageheight":64,'
//	   					+'"imagewidth":64'
//	   				+'},';
//  		}else{
//  			var robot = '"3":'
//	   				+'{'
//	   					+'"image":"..\/img\/mapPack\/PNG\/mapTile_077.png",'
//	   					+'"imageheight":64,'
//	   					+'"imagewidth":64'
//	   				+'},';
//
//  		}
// 		if($("input[id='myonoffswitch3']").is(':checked')){
//  			var obstacles = '"2":'
//	   				+'{'
//	   					+'"image":"..\/img\/mapPack\/PNG\/mapTile_094.png",'
//	   					+'"imageheight":64,'
//	   					+'"imagewidth":64'
//	   				+'},';
//  			var obstacles2= '"5":'
// 				+'{'
// 					+'"image":"..\/img\/mapPack\/PNG\/mapTile_040.png",'
// 					+'"imageheight":64,'
// 					+'"imagewidth":64'
// 				+'}';
//  		}else{
//  			var obstacles = '"2":'
//	   				+'{'
//	   					+'"image":"..\/img\/mapPack\/PNG\/mapTile_077.png",'
//	   					+'"imageheight":64,'
//	   					+'"imagewidth":64'
//	   				+'},';
//  			var obstacles2= '"5":'
//   				+'{'
//					+'"image":"..\/img\/mapPack\/PNG\/mapTile_077.png",'
//					+'"imageheight":64,'
//					+'"imagewidth":64'
//				+'}';
//
//  		}
//  		
//	
//
//  		var obj = '{'
//  			   +'"height" : '+data[0]+','
//  			   +'"infinite":false,'
//  			   +'"layers":['
//  				   +'{'
//	                       +'"data"  : ['+data.slice(2)+'],'
//	    		       	   +'"height" : '+data[0]+','
//	    		       	   +'"id" : 1,'
//	    		           +'"name":"background",'
//	    		           +'"opacity":1,'
//	    		           +'"type":"tilelayer",'
//	    		           +'"visible":true,'
//	    		           +'"width" : '+data[1]+','
//	    		           +'"x":0,'
//	    		           +'"y":0'
//  		       	   +'}'
//  		       +'],'
//  		       +'"nextlauyerid":6,'
//  		       +'"nextobjectid":1,'
//  		       +'"orientation":"orthogonal",'
//  		       +'"renderorder":"left-up",'
//  		       +'"tiledversion":"1.1.5",'
//  		       +'"tileheight":64,'
//  		       +'"tilesets":['
//  		    	   +'{'
//  		    	   	+'"columns":0,'
//  		    	   	+'"firstgid":1,'
//  		    	   	+'"grid":'
//  		    	   		+'{'
//  		    	   			+'"height":1,'
//  		    	   			+'"orientation":"orthogonal",'
//  		    	   			+'"width":1'
//  		    	   		+'},'
//  		    	   	+'"margin":0,'
//  		    	   	+'"name":"elts",'
//  		    	   	+'"spacing":0,'
//  		    	   	+'"tilecount":188,'
//  		    	   	+'"tileheight":64,'
//  		    	   	+'"tiles":'
//  		    	   		+'{'
//  		    	   			+'"0":'
//  		    	   				+'{'
//  		    	   					+'"image":"..\/img\/mapPack\/PNG\/mapTile_171.png",'
//  		    	   					+'"imageheight":64,'
//  		    	   					+'"imagewidth":64'
//  		    	   				+'},'
//      		    	   		+'"1":'
//  		    	   				+'{'
//  		    	   					+'"image":"..\/img\/mapPack\/PNG\/mapTile_077.png",'
//  		    	   					+'"imageheight":64,'
//  		    	   					+'"imagewidth":64'
//  		    	   				+'},'    
//      		    	   		+obstacles
//  	      		    	   	+ robot
//	      		    	   		+trace
//	      		    	   		+ obstacles2
//	      		    	   		+ '},'
//	      		    	   		+'"tilewidth":64'
//  		    	   		+'}],'
//  		    	   	+'"tilewidth":64,'
//  		    	   	+'"type":"map",'
//  		    	   	+'"version":1,'
//  		    	   	+'"width":100'
//  		       +'}';
//  		       
//  		  mapMng.loadTileset(JSON.parse(obj));
//  	          
//          }
//      ,
//      failure: function(errMsg) {
//          alert(errMsg);
//      },
//      type: "GET",
//      url: "/map",
//      // The key needs to match your method's input parameter (case-sensitive).
//      contentType: "application/json; charset=utf-8"
//  });   
//
//  setTimeout(function() { 
//	  mapMng.scale_factor=1.4;
//	  mapMng.rerenderall();   
//  }, 100);
//  //mapMng.load("customMap");
//    
//  $(document).on('input change', '#scaleButtonId', function() {
//    var current_val=$("#scaleButtonId")[0].value;
//    mapMng.scale_factor=current_val;
//
//    mapMng.rerenderall();  
//  });
//});
//
