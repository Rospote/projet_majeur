import {MapMng} from './MapMng.js';
import {Button} from './button.js';
import {Request} from './ajaxRequest.js';
//Define la classe commande associée a la page cmd.html
//Gère l'interaction entre utilisateur et background
	
	var trace = '077';
	var robot = '136';
	var obstacles = '110';
	var obstacles2= '040';
	
	var chartNbCommandes;
	var chartNbDistance;
	var chartObstaclesVisibles;
	var chartObstaclesRencontrées;
	var nbRefresh;
	
function check(){
	
	 if($("input[id='myonoffswitch2']").is(':checked')){
		   trace = '034';	  	
		  }
	  else{
 		trace = '077';
 		}
		if($("input[id='myonoffswitch']").is(':checked')){
 			  robot = '136';
 		}else{
 			  robot = '077';
 		}
		if($("input[id='myonoffswitch3']").is(':checked')){
 			 obstacles = '110';
 			  obstacles2= '040';
 		}else{
 			  obstacles = '077';
 			  obstacles2= '077';
 		}
}


function reload_map(){
	update_graph();
	$(function() {
		  var c = $("canvas")[0].getContext("2d");
		  let mapMng=new MapMng(c,[]);
		  
		  $.ajax ({
		  	success: function (data) {
					
		  		var obj = '{'
		  			   +'"height" : '+data[0]+','
		  			   +'"infinite":false,'
		  			   +'"layers":['
		  				   +'{'
			                       +'"data"  : ['+data.slice(2)+'],'
			    		       	   +'"height" : '+data[0]+','
			    		       	   +'"id" : 1,'
			    		           +'"name":"background",'
			    		           +'"opacity":1,'
			    		           +'"type":"tilelayer",'
			    		           +'"visible":true,'
			    		           +'"width" : '+data[1]+','
			    		           +'"x":0,'
			    		           +'"y":0'
		  		       	   +'}'
		  		       +'],'
		  		       +'"nextlauyerid":6,'
		  		       +'"nextobjectid":1,'
		  		       +'"orientation":"orthogonal",'
		  		       +'"renderorder":"left-up",'
		  		       +'"tiledversion":"1.1.5",'
		  		       +'"tileheight":64,'
		  		       +'"tilesets":['
		  		    	   +'{'
		  		    	   	+'"columns":0,'
		  		    	   	+'"firstgid":1,'
		  		    	   	+'"grid":'
		  		    	   		+'{'
		  		    	   			+'"height":1,'
		  		    	   			+'"orientation":"orthogonal",'
		  		    	   			+'"width":1'
		  		    	   		+'},'
		  		    	   	+'"margin":0,'
		  		    	   	+'"name":"elts",'
		  		    	   	+'"spacing":0,'
		  		    	   	+'"tilecount":188,'
		  		    	   	+'"tileheight":64,'
		  		    	   	+'"tiles":'
		  		    	   		+'{'
		  		    	   			+'"0":'
		  		    	   				+'{'
		  		    	   					+'"image":"..\/img\/mapPack\/PNG\/mapTile_171.png",'
		  		    	   					+'"imageheight":64,'
		  		    	   					+'"imagewidth":64'
		  		    	   				+'},'
		      		    	   		+'"1":'
		  		    	   				+'{'
		  		    	   					+'"image":"..\/img\/mapPack\/PNG\/mapTile_077.png",'
		  		    	   					+'"imageheight":64,'
		  		    	   					+'"imagewidth":64'
		  		    	   				+'},'    
		      		    	   		+'"2":'
		  		    	   				+'{'
		  		    	   					+'"image":"..\/img\/mapPack\/PNG\/mapTile_'+obstacles+'.png",'
		  		    	   					+'"imageheight":64,'
		  		    	   					+'"imagewidth":64'
		  		    	   				+'},'
		  	      		    	   	+'"3":'
		  		    	   				+'{'
		  		    	   					+'"image":"..\/img\/mapPack\/PNG\/mapTile_'+robot+'.png",'
		  		    	   					+'"imageheight":64,'
		  		    	   					+'"imagewidth":64'
		  		    	   				+'},'
		  	  	      		    	+'"4":'
		  		    	   				+'{'
		  		    	   					+'"image":"..\/img\/mapPack\/PNG\/mapTile_'+trace+'.png",'
		  		    	   					+'"imageheight":64,'
		  		    	   					+'"imagewidth":64'
		  		    	   				+'},'
		      		    	   		+'"5":'
		  		    	   				+'{'
		  		    	   					+'"image":"..\/img\/mapPack\/PNG\/mapTile_'+obstacles2+'.png",'
		  		    	   					+'"imageheight":64,'
		  		    	   					+'"imagewidth":64'
		  		    	   				+'},'
		  		    	   			+'"tilewidth":64}'
		  		    	   		+'}],'
		  		    	   	+'"tilewidth":64,'
		  		    	   	+'"type":"map",'
		  		    	   	+'"version":1,'
		  		    	   	+'"width":100'
		  		       +'}';
		  		       
		  		  mapMng.loadTileset(JSON.parse(obj));
		  	          
		          }
		      ,
		      failure: function(errMsg) {
		          alert(errMsg);
		      },
		      type: "GET",
		      url: "/map",
		      // The key needs to match your method's input parameter (case-sensitive).
		      contentType: "application/json; charset=utf-8"
		  });   

		  setTimeout(function() { 
			  mapMng.scale_factor=1.4;
			  mapMng.rerenderall();   
		  }, 100);
		  //mapMng.load("customMap");
		    
		  $(document).on('input change', '#scaleButtonId', function() {
		    var current_val=$("#scaleButtonId")[0].value;
		    mapMng.scale_factor=current_val;

		    mapMng.rerenderall();  
		  });
		});
	
}


function init_graph(){
	
	nbRefresh = 0;
	
		chartNbCommandes = new CanvasJS.Chart("chartContainer", {
		animationEnabled: true,
		theme: "light2",
		title:{
			text: "Commandes executées"
		},
		axisY:{
			includeZero: false
		},
		axisX:{
			minimum: 0
		},
		data: [{        
			type: "line",       
			dataPoints: [
				{ y: 0 }
			]
		}]
	});
		

		chartNbDistance = new CanvasJS.Chart("chartContainer2", {
		animationEnabled: true,
		theme: "light2",
		title:{
			text: "Distance parcourue"
		},
		axisY:{
			includeZero: false
		},
		axisX:{
			minimum: 0
		},
		data: [{        
			lineColor: "green",
			type: "line",       
			dataPoints: [
				{ y: 0 }
			]
		}]
	});
		

		chartObstaclesVisibles = new CanvasJS.Chart("chartContainer3", {
		animationEnabled: true,
		theme: "light2",
		title:{
			text: "Obstacles visibles"
		},
		axisY:{
			includeZero: false
		},
		axisX:{
			minimum: 0
		},
		data: [{   
			lineColor: "orange",
			type: "line",       
			dataPoints: [
				{ y: 0 }
			]
		}]
	});
		

		chartObstaclesRencontrées = new CanvasJS.Chart("chartContainer4", {
		animationEnabled: true,
		theme: "light2",
		title:{
			text: "Obstacles rencontrées"
		},
		axisY:{
			includeZero: false
		},
		axisX:{
			minimum: 0
		},
		data: [{        
			lineColor: "red",
			type: "line",       
			dataPoints: [
				{ y: 0 }
			]
		}]
	});
	
	
}

init_graph();

function update_graph() {
	
	nbRefresh++;
	
	  $.ajax ({
		  	success: function (data) {
		  	//	alert(data);

		  			chartNbCommandes.options.data[0].dataPoints.push({y: parseInt(data[0])}); 
		  			chartNbDistance.options.data[0].dataPoints.push({y: parseInt(data[1]),color: "green"}); 
		  			chartObstaclesVisibles.options.data[0].dataPoints.push({y: parseInt(data[2]),color: "orange"}); 
		  			chartObstaclesRencontrées.options.data[0].dataPoints.push({y: parseInt(data[3]),color: "red"}); 

		  	          
		          }
		      ,
		      failure: function(errMsg) {
		          alert(errMsg);
		      },
		      type: "GET",
		      url: "/measures",
		      // The key needs to match your method's input parameter (case-sensitive).
		      contentType: "application/json; charset=utf-8"
		  });   
	

	  chartNbCommandes.options.axisX.minimum = nbRefresh - 20;
	  chartNbCommandes.render();
	  
	  chartNbDistance.options.axisX.minimum = nbRefresh - 20;
	  chartNbDistance.render();
	  
	  chartObstaclesVisibles.options.axisX.minimum = nbRefresh - 20;
	  chartObstaclesVisibles.render();
	  
	  chartObstaclesRencontrées.options.axisX.minimum = nbRefresh - 20;
	  chartObstaclesRencontrées.render();

}



class Cmd {
	
	constructor() {
		this.buttonUp = new Button('UP'); 
		this.buttonDown = new Button('DOWN');
		this.buttonRight = new Button('RIGHT');
		this.buttonLeft = new Button('LEFT');
		this.buttonAuto = new Button('AUTO');
		this.buttonLock = new Button('LOCK');
		this.auto = false;
		this.defineInteractions= this.defineInteractions.bind(this);
		this.defineInteractions();
		this.canConnect=this.canConnect.bind(this);	
		this.interval = setInterval(function(){console.log(this.auto);if(this.auto){ reload_map();} }, 1000);
		
		
		 //alert('Construit Cmd !');
		
	}
	

	 //local function
    defineInteractions(){
        //define behavior on the evt click, CAUTION need to bind the function inside to the curret this
         $("#up").click( 
             function(){    
                 this.request = new Request("/cmd/"+this.buttonUp.getType()); 
                 reload_map();
                }.bind(this)
         );
         $("#down").click( 
        		 function(){    
                     this.request = new Request("/cmd/"+this.buttonDown.getType());
                     reload_map();
                    }.bind(this)
         );
         $("#right").click( 
        		 function(){    
                     this.request = new Request("/cmd/"+this.buttonRight.getType());
                     reload_map();
                    }.bind(this)
         );
         $("#left").click( 
        		 function(){     
                     this.request = new Request("/cmd/"+this.buttonLeft.getType());
                     reload_map();
                    }.bind(this)
         );
         $("#auto").click( 
        		 function(){     
                     this.request = new Request("/cmd/AUTO");
                     this.auto = !this.auto;
                    }.bind(this)
         );
         $("#LOCK").click( 
	  		 function(){ 
	  			//alert("ajax2");                     
		             $.ajax ({
		       		  success: function (stateCourant) {
		       			   	this.stateCourant=stateCourant;
		       			   	this.canConnect();
		       		  	  }.bind(this)
		       		      ,
		       		      failure: function(errMsg) {
		       		          alert(errMsg);
		       		      },
		       		      type: "GET",
		       		      url: "/state/get",
		       		      // The key needs to match your method's input parameter (case-sensitive).
		       		      contentType: "application/json; charset=utf-8"	  
		   		  });                 
                  }.bind(this)
         );
         
         $("#myonoffswitch").click( 
        		 function(){     
        			 check();
                    }.bind(this)
         );
         $("#myonoffswitch2").click( 
        		 function(){     
        			 check();                    
        			 }.bind(this)
         );
         $("#myonoffswitch3").click( 
        		 function(){     
        			 check();
        			 }.bind(this)
         );
         $("#reset").click( 
        		 function(){     
                     this.request = new Request("/cmd/RESET");
        			 }.bind(this)
         );
    }
	canConnect(){
			 let el = document.getElementById('LOCK');
			 
		     //Deux personnes connectées mais une prend le control --> la personne qui essaye de prendre le controle est redirigée
		     if (this.stateCourant == "Busy" && el.firstChild.data == "Lock"){
		    	 alert("Robot déjà en cours d'utilisation, merci de rééssayer ultérieurement")
		    	 window.location = "/waiting.html"; 
		     }
		     
		     //Une personne réserve le robot
		     else if (this.stateCourant == "Free" && el.firstChild.data == "Lock" ){
		    	 el.firstChild.data = "UnLock";
		         this.request = new Request("/state"); //change état du model
		     }
		     
		     else if(this.stateCourant == "Busy" && el.firstChild.data == "UnLock"){
		    	 window.location = "/waiting.html"; 
		    	 this.request = new Request("/state"); //change état du model
		     }
		     //la personne ne réserve plus le robot
		     else {
		    	 window.location = "/waiting.html"; 

		     	}
		   }
	
}



//Usage of jquery, waiting all document is ready
$(function() {
    //create a variable a from the class A in the current a.js file
	let cmd = new Cmd(); 
	//this.defineInteractions();
	//const cmd = new Cmd();  

});

