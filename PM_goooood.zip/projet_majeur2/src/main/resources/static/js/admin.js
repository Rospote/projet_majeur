class Login {
	

	constructor() {
		
		this.defineInteractions= this.defineInteractions.bind(this);
		this.defineInteractions();
		
  }
 
    defineInteractions(){
    	//Definition des evenements lorsqu'on clique sur le bouton
         $("#buttonId").click( 
             function(){    
            	this.connexion();
                }.bind(this)
         );
    }
    
    //fonction connexion qui fait la conexion AJAX et interroge la base de donnée lors de la tentative de login
    connexion(){
    	
    	let login = document.getElementsByName("login")[0].value;
        let password = document.getElementsByName("password")[0].value;
        
        
        //vérification de l'existence de l'utilisateur dans la base de données
        let xhr = new XMLHttpRequest();
        xhr.open("POST", '/login', true);
        xhr.setRequestHeader("Content-type", "application/json");
        let data = JSON.stringify({"login":String(login),"password":String(password)});
        
        
        xhr.send(data);
        
        xhr.addEventListener('readystatechange',function(){
    		if(xhr.readyState===4 && xhr.status ===200){	
    			
    			if(xhr.responseText=="true"){
      	        	let xhr2 = new XMLHttpRequest();
    	            xhr2.open("GET", '/login/'+login,true);
    	            xhr2.onreadystatechange = function() {
    	                if (xhr2.readyState == 4 && (xhr.status == 200 || xhr.status == 0)) {
    	                	let adminId = xhr2.responseText;
    					sessionStorage.setItem('id', 1);
    				    window.location="/admin-logged.html";
    	                }
    	            };
    	            xhr2.send(null);
    			}
    			else{
    				alert("Le nom d'utilisateur ou le mot de passe est incorrect");
    			}
    		}
    	
    	});
    	
    	
    }
 
}


$(function() {
	
	let login = new Login();

});