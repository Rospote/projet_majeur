import {Request} from './ajaxRequest.js';

class Wait{
	
	constructor(){
		
		//on gÃ©nere un id unique pour la personne qui vient de se connecter sur la page
		var id = '_' + Math.random().toString(36).substr(2, 9);
		this.id = id;
		var power;
		var userCourant;
		var stateCourant;

		this.defineInteractions= this.defineInteractions.bind(this);
		this.isConnected=this.isConnected.bind(this);
		this.defineInteractions();	

	}
	
	defineInteractions(){
         $("#connexion").click( 
             function(){ 
            	 $.ajax ({
            		  success: function (userCourant) {
            			  this.userCourant=userCourant;
            		  }.bind(this)
            		      ,
            		      failure: function(errMsg) {
            		          alert(errMsg);
            		      },
            		      type: "GET",
            		      url: "/use/get",
            		      // The key needs to match your method's input parameter (case-sensitive).
            		      contentType: "application/json; charset=utf-8"
            		      
            		  });
            	 	
            		  $.ajax ({
                		  success: function (stateCourant) {
                			   	this.stateCourant=stateCourant;
                             	this.isConnected();

                		  	  }.bind(this)
                		      ,
                		      failure: function(errMsg) {
                		          alert(errMsg);
                		      },
                		      type: "GET",
                		      url: "/state/get",
                		      // The key needs to match your method's input parameter (case-sensitive).
                		      contentType: "application/json; charset=utf-8"	  
            		  }); 
            		  
            		  $.ajax ({
                		  success: function (power) {
                			   	this.power=power;

                		  	  }.bind(this)
                		      ,
                		      failure: function(errMsg) {
                		          alert(errMsg);
                		      },
                		      type: "GET",
                		      url: "/power/get",
                		      // The key needs to match your method's input parameter (case-sensitive).
                		      contentType: "application/json; charset=utf-8"	  
            		  }); 
            		  
                }.bind(this));

        			 
  
	}
      isConnected(){  
    	  if (this.power!=false){
                //Si l'ID crÃ©e est diffÃ©rent de l'ID courant et que robot libre --> cmd.html 
            	if (this.stateCourant=="Free" && this.userCourant!=this.id){
            		//TODO met a jour l'userCourant --> redirige vers cmd.html
            		 this.request = new Request("/use/"+this.id);
            		 window.location = "/cmd.html";
            	}
            	else if(this.stateCourant=="Busy" && this.userCourant!=this.id){
            		$("#h2_1").html("Robot en cours d'utilisation ...");
            	}
            	else {
            		window.location = "/cmd.html";
            		}
            		
    	  }
    	  else {
    		  $("#h2_1").html("Robot non démarré par l'administrateur");
    	  }
      }
}

  

$(function() {
    let wait = new Wait();
   
});